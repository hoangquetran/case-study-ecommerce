import React from "react";

const AboutUs = () => {
    return(
        <div>
            About Us
        </div>
    )
}

export default AboutUs;