import React from "react";

const ContactUs = () => {
    return(
        <div>
            Please contact me via : aaaaa@myshop.com
        </div>
    )
}

export default ContactUs;