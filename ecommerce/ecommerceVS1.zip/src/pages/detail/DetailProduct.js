import React from "react";

const DetailProduct = () => {
    
    return(
        <div>
            hgfhgfhf
        </div>
    )
}

export default DetailProduct;