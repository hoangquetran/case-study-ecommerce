// import logo from './logo.svg';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import NavbarShop from './components/navbar/Navbar';
import Header from './components/layout/Header'

function App() {
  return (
    <div className="main">
      <header className="header">
          <Header />
          <NavbarShop />
      </header>
    </div>
  );
}

export default App;
