import React from "react";
import { Link } from "react-router-dom";
import { Col } from "react-bootstrap";

const ProductItem = (props) => {
    return(
        <Col className="product" xs={3}>
            <Link to={`/${props.id|''}`} target="_blank">
                <div className="product-img">
                    <img src={props.image} alt="product" />
                </div>
                <div className="product-txt">
                    <p className="product-cate">{props.category}</p>
                    <p className="product-ttl">{props.title}</p>
                    <p className="product-price">${props.price}</p>
                    <button>Add to cart</button>
                </div>
            </Link>
        </Col>
    )
}

export default ProductItem;