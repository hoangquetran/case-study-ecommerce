import React, { useEffect, useState } from "react";
import Row from 'react-bootstrap/Row';
import productAPI from "../../api";
import ProductItem from "./ProductItem";
import './products.css';

const ListProduct = () => {
    const [products, setProduct] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        getProduct();
    },[isLoading]);

    const getProduct = async () => {
        const response = await productAPI.get('products/');
        setProduct(response.data)
        setIsLoading(false)
    };

    return(
        <Row className="list-products">
            {products.map((product) => {
                return(
                    <ProductItem key={product.id} {...product} />
                )
            })}
        </Row>
    )
}

export default ListProduct;