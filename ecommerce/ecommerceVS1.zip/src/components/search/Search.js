import React from "react";
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Search = () => {
    return(
        // <div class="header-search-form-wrapper">
        //     <div class="searchform-wrapper ux-search-box relative form-flat is-normal">
        //         <form role="search" method="get" class="searchform" action="https://flatsome3.uxthemes.com/">
        //             <div class="flex-row relative">
        //                 <div class="flex-col flex-grow">
        //                     <label class="screen-reader-text" for="woocommerce-product-search-field-0">Search for:</label>
        //                     <input type="search" class="search-field mb-0" placeholder="Search…" value="" name="s" autocomplete="off"/> 
        //                     <input type="hidden" name="post_type" value="product"/>
        //                 </div>
        //                 <div class="flex-col">
        //                     <button type="submit" value="Search" class="ux-search-submit submit-button secondary button icon mb-0" aria-label="Submit"> 
        //                         <i class="icon-search"></i> 
        //                     </button>
        //                 </div>
        //             </div>
        //             <div class="live-search-results text-left z-top">
        //                 <div class="autocomplete-suggestions">
        //                 </div>
        //             </div>
        //         </form>
        //     </div>
        // </div>
        <div className="input-group">
            <div className="form-outline">
                <input id="search-focus" type="search" className="form-control" />
                <label className="form-label" for="form1">Search</label>
            </div>
            <button type="button" className="btn btn-primary">
                <i className="fa fa-search"></i>
            </button>
        </div>
    )
}

export default Search;
