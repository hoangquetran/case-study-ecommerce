import React from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import {Link} from 'react-router-dom';
import { Bag } from 'react-bootstrap-icons';
import './cart.css';

const CartHeader = () => {
    return(
        <Link to="/cart" className="cart">
            <Row className="align-items-md-center">
                <Col className="cart-txt"><p>Cart /</p></Col>
                <Col className="cart-bag"><Bag color="#ffffff" size={32} /></Col>
            </Row>
        </Link>
    )
}

export default CartHeader;