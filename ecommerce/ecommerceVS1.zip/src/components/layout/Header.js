import React from "react";
// import Search from "../search/Search";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Login from "../login/Login";
import CartHeader from "../cart/Cart";
import { Link } from "react-router-dom";

import './header.css'

const Header = () => {
    return(
        <Container>
            <Row className="align-items-md-center">
                <Col></Col>
                <Col xs={6} className="h1">
                    <Link to="/">Myshop</Link>
                </Col>
                <Col>
                    <Row className="align-items-md-center">
                        <Col xs={6}><Login /></Col>
                        <Col><CartHeader /></Col>
                    </Row>
                </Col>
            </Row>
        </Container>
    )
}

export default Header;