import React from "react";
import FilterByType from "../filter/FilterByType";

const Sidebar = () => {
   

    return(
        <div>
           <FilterByType />
        </div>
    )
}

export default Sidebar;