import React from "react";

const FilterByType = () => {
    return(
        <div>
            <h4>Product Type</h4>
        </div>
    )
}

export default FilterByType;